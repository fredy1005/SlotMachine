/**
 * Representa un único rodillo de la máquina tragamonedas.
 * Un rodillo no almacena sus propios símbolos; solo guarda el índice del
 * símbolo visible en ese momento, haciendo referencia al catálogo de símbolos
 * compartido de la máquina (todos los rodillos comparten el mismo conjunto ordenado de símbolos).
 * @author  (Hernández-Rodríguez)
 * 
 */
public class Wheel {

    private int currentIndex;

    /**
     * Crea una nueva rueda que muestra el primer símbolo del catálogo
     * (índice 0) por defecto.
     */
    public Wheel() {
        currentIndex = 0;
    }

    /**
     * Devuelve el índice (basado en cero) del símbolo actualmente visible.
     * @return el índice actual en el catálogo de símbolos compartido
     */
    public int getCurrentIndex() {
        return currentIndex;
    }

    /**
     * Establece directamente el índice actual. Se utiliza 
     * internamente cuando el catálogo de símbolos cambia de tamaño 
     * y los índices deben mantenerse dentro de los límites
     * @param index el nuevo índice (basado en cero)
     */
    public void setCurrentIndex(int index) {
        currentIndex = index;
    }
}