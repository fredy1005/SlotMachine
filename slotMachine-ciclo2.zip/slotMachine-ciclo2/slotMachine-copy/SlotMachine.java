import java.util.ArrayList;
import java.util.List;

/**
 * Simulación Slot Machine, Proyecto 1 DOPO
 *
 * @author  (Hernández-Rodríguez)
 * @version 1.0 (Miniciclo 1)
 */
public class SlotMachine {

    private List<Wheel> wheels;
    private List<String> symbolCatalog;
    private boolean lastOperationOk;
    private boolean visible;

    /**
     * Maquina tragamonedas vacía sin rodillos ni símbolos definidos
     */
    public SlotMachine() {
        wheels = new ArrayList<>();
        symbolCatalog = new ArrayList<>();
        lastOperationOk = true;
        visible = false;
    }

    /**
     * * Añade una nueva rueda en la posición indicada. Las posiciones se numeran a partir de 1,
     * los valores inferiores a 1 se ajustan a 1 y los valores superiores al número actual
     * de ruedas más 1 se ajustan a dicho máximo (añadiéndose al final)
     */
    public void addWheel(int pos) {
        int clamped = clamp(pos, 1, wheels.size() + 1);
        wheels.add(clamped - 1, new Wheel());
        lastOperationOk = true;
    }

    /**
     * Elimina la rueda en la posición indicada. Las posiciones se numeran a partir de 1 y
     * se ajustan al rango [1, número de ruedas]. La operación falla si no hay ruedas
     * @param pos la posición de la rueda que se va a eliminar
     */
    public void delWheel(int pos) {
        if (wheels.isEmpty()) {
            lastOperationOk = false;
            return;
        }
        int clamped = clamp(pos, 1, wheels.size());
        wheels.remove(clamped - 1);
        lastOperationOk = true;
    }

    /**
     * Añade un nuevo símbolo, identificado por un nombre de color CSS, al catálogo
     * compartido en la posición indicada (basada en 1, con ajuste de límites). La operación falla si el
     * color no es un nombre de CssColor válido o si ya existe en el catálogo.
     * @param la posición deseada en el catálogo
     * @param color el nombre de color CSS que identifica el símbolo
     */
    public void addSymbol(int pos, String color) {
        if (!CssColors.isValid(color) || symbolCatalog.contains(color)) {
            lastOperationOk = false;
            return;
        }
        int clamped = clamp(pos, 1, symbolCatalog.size() + 1);
        symbolCatalog.add(clamped - 1, color);
        lastOperationOk = true;
    }

    /**
     * Elimina un símbolo del catálogo compartido a partir de su nombre de color. Cualquier
     * rueda cuyo índice actual quede fuera del nuevo tamaño del catálogo
     * se ajusta para volver a estar dentro del rango. La operación falla si el símbolo no existe.
     * @param symbol el nombre de CssColor del símbolo que se va a eliminar
     */
    public void delSymbol(String symbol) {
        int index = symbolCatalog.indexOf(symbol);
        if (index == -1) {
            lastOperationOk = false;
            return;
        }
        symbolCatalog.remove(index);
        adjustWheelIndexes();
        lastOperationOk = true;
    }

    /**
     * Indica si la última operación realizada en esta máquina
     * se completó correctamente.
     * @return true si la última operación tuvo éxito
     */
    public boolean ok() {
        return lastOperationOk;
    }

    /**
     * Devuelve los colores de los símbolos del catálogo compartido, en su
     * orden actual, comenzando desde la posición 1.
     * @return un arrayList con los colores del catálogo
     */
    public String[] symbols() {
        return symbolCatalog.toArray(new String[0]);
    }

    /**
     * Devuelve los colores actualmente visibles en cada rueda, ordenados de
     * izquierda a derecha.
     * @return un arrayList con el color visible de cada rueda
     */
    public String[] configuration() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) {
            result[i] = colorAt(wheels.get(i));
        }
        return result;
    }

    /**
     * Devuelve cuántos colores distintos son visibles actualmente en
     * todos los rodillos.
     * @return el número de símbolos visibles distintos
     */
    public int distinctSymbols() {
        List<String> distinct = new ArrayList<>();
        for (Wheel w : wheels) {
            String color = colorAt(w);
            if (color != null && !distinct.contains(color)) {
                distinct.add(color);
            }
        }
        return distinct.size();
    }

    /**
     * Indica si la configuración actual es ganadora,
     * es decir, si todos los rodillos muestran el mismo símbolo.
     * @return true si hay al menos un rodillo y todos muestran el
     * mismo color
     */
    public boolean isJackpot() {
        return !wheels.isEmpty() && distinctSymbols() == 1;
    }

    // Métodos planteados para siguientes mini-ciclos

    /**
     * Establece directamente el símbolo visible de una rueda (manipulación secreta).
     * @param wheel la posición de la rueda (basada en índice 1)
     * @param symbol el nombre del color CSS que se va a colocar
     */
    public void placeSymbol(int wheel, String symbol) {
        lastOperationOk = false; 
        // Miniciclo 2
    }

    /**
     * Rota una sola rueda una posición.
     * @param wheel la posición de la rueda (basada en 1)
     */
    public void spin(int wheel) {
        lastOperationOk = false; 
        // Miniciclo 2
    }

    /**
     * Rota cada rueda de la máquina una posición.
     */
    public void spin() {
        lastOperationOk = false; // Miniciclo 2
    }

    /**
     * Hace visible la representación gráfica de la máquina.
     */
    public void makeVisible() {
        visible = true; // dibujo real con shapes (Miniciclo 3)
        lastOperationOk = true;
    }

    /**
     * Hace invisible la representación gráfica de la máquina. La
     * máquina sigue funcionando con normalidad mientras es invisible.
     */
    public void makeInvisible() {
        visible = false;
        lastOperationOk = true;
    }

    /**
     * Finaliza el simulador, dando los recursos gráficos.
     */
    public void exit() {
        lastOperationOk = true; //Miniciclo 5
    }

    // Metodos privados

    /**
     * Devuelve el color actualmente visible en una rueda determinada, o null si
     * el catálogo está vacío.
     * @param w la rueda a consultar
     * @return el color visible, o null si aún no hay catálogo
     */
    private String colorAt(Wheel w) {
        if (symbolCatalog.isEmpty()) {
            return null;
        }
        return symbolCatalog.get(w.getCurrentIndex());
    }

    /**
     * Mantiene el índice actual de cada rueda dentro del rango válido del catálogo 
     * de símbolos (posiblemente reducido) tras una eliminación.
     */
    private void adjustWheelIndexes() {
        if (symbolCatalog.isEmpty()) {
            return;
        }
        for (Wheel w : wheels) {
            if (w.getCurrentIndex() >= symbolCatalog.size()) {
                w.setCurrentIndex(symbolCatalog.size() - 1);
            }
        }
    }

    /**
     * Ajusta una posición (basada en índice 1) al rango especificado.
     * @param la posición solicitada
     * @param min el valor mínimo permitido
     * @param max el valor máximo permitido
     * @return la posición ajustada
     */
    private int clamp(int pos, int min, int max) {
        if (pos < min) return min;
        if (pos > max) return max;
        return pos;
    }
}