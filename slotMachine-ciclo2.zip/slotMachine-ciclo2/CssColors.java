import java.util.HashSet;
import java.util.Set;

/**
 * Clase que valida si un nombre dado corresponde a una
* palabra clave de color CSS estándar. Se utiliza para hacer
* cumplir la regla de que cada símbolo en la máquina tragamonedas 
* debe identificarse mediante un nombre de CssColor válido
*
 * @author (Hernández-Rodríguez)
 */
public class CssColors {

    private static final Set<String> VALID_COLORS = new HashSet<>();

    static {
        String[] names = {
            "aliceblue","antiquewhite","aqua","aquamarine","azure","beige",
            "bisque","black","blanchedalmond","blue","blueviolet","brown",
            "burlywood","cadetblue","chartreuse","chocolate","coral",
            "cornflowerblue","cornsilk","crimson","cyan","darkblue","darkcyan",
            "darkgoldenrod","darkgray","darkgreen","darkgrey","darkkhaki",
            "darkmagenta","darkolivegreen","darkorange","darkorchid","darkred",
            "darksalmon","darkseagreen","darkslateblue","darkslategray",
            "darkslategrey","darkturquoise","darkviolet","deeppink",
            "deepskyblue","dimgray","dimgrey","dodgerblue","firebrick",
            "floralwhite","forestgreen","fuchsia","gainsboro","ghostwhite",
            "gold","goldenrod","gray","grey","green","greenyellow","honeydew",
            "hotpink","indianred","indigo","ivory","khaki","lavender",
            "lavenderblush","lawngreen","lemonchiffon","lightblue",
            "lightcoral","lightcyan","lightgoldenrodyellow","lightgray",
            "lightgreen","lightgrey","lightpink","lightsalmon","lightseagreen",
            "lightskyblue","lightslategray","lightslategrey","lightsteelblue",
            "lightyellow","lime","limegreen","linen","magenta","maroon",
            "mediumaquamarine","mediumblue","mediumorchid","mediumpurple",
            "mediumseagreen","mediumslateblue","mediumspringgreen",
            "mediumturquoise","mediumvioletred","midnightblue","mintcream",
            "mistyrose","moccasin","navajowhite","navy","oldlace","olive",
            "olivedrab","orange","orangered","orchid","palegoldenrod",
            "palegreen","paleturquoise","palevioletred","papayawhip",
            "peachpuff","peru","pink","plum","powderblue","purple",
            "rebeccapurple","red","rosybrown","royalblue","saddlebrown",
            "salmon","sandybrown","seagreen","seashell","sienna","silver",
            "skyblue","slateblue","slategray","slategrey","snow",
            "springgreen","steelblue","tan","teal","thistle","tomato",
            "turquoise","violet","wheat","white","whitesmoke","yellow",
            "yellowgreen"
        };
        for (String n : names) {
            VALID_COLORS.add(n);
        }
    }

    private CssColors() {
        // Clase utilitaria que no se instancia.
    }

    /**
     * Indica si el nombre proporcionado es una palabra clave estándar
     * de CssColor. La comparación no distingue entre mayúsculas y minúsculas.
     * @param color el nombre del color a validar
     * @return true si es un nombre de CssColor válido
     */
    public static boolean isValid(String color) {
        return color != null && VALID_COLORS.contains(color.toLowerCase());
    }
}