import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

/**
 * Pruebas de unidad individuales del Ciclo 2. Todas se ejecutan con la
 * máquina en modo invisible, tal como exige el enunciado.
 *
 * Cada prueba está pensada en pares: "qué debería hacer" (caso feliz) y
 * "qué NO debería hacer" (caso de falla / borde), tal como pide el
 * enunciado.
 *
 * @author  (Hernández-Rodríguez)
 * @version 2.0 (Miniciclo 2)
 */
public class SlotMachineC2Test {

    private SlotMachine machine;

    /**
     * Crea una máquina con 3 ruedas y 3 símbolos antes de cada prueba,
     * siempre en modo invisible.
     */
    @Before
    public void setUp() {
        machine = new SlotMachine();
        machine.makeInvisible();
        machine.addWheel(1);
        machine.addWheel(2);
        machine.addWheel(3);
        machine.addSymbol(1, "red");
        machine.addSymbol(2, "green");
        machine.addSymbol(3, "blue");
    }

    // ---------------- swap ----------------

    /** swap SÍ debería intercambiar el símbolo visible de dos ruedas. */
    @Test
    public void swapShouldExchangeVisibleSymbols() {
        machine.spin(2); // rueda 2 avanza un paso
        String[] before = machine.configuration();
        machine.swap(1, 2);
        String[] after = machine.configuration();
        assertEquals(before[0], after[1]);
        assertEquals(before[1], after[0]);
        assertTrue(machine.ok());
    }

    /** swap NO debería tener éxito si la máquina no tiene ruedas. */
    @Test
    public void swapShouldNotSucceedWithoutWheels() {
        SlotMachine empty = new SlotMachine();
        empty.makeInvisible();
        empty.swap(1, 2);
        assertFalse(empty.ok());
    }

    // ---------------- lock / unlock ----------------

    /** Una rueda bloqueada NO debería moverse al girar. */
    @Test
    public void lockedWheelShouldNotSpin() {
        machine.lock(1);
        String before = machine.configuration()[0];
        machine.spin(1);
        assertFalse(machine.ok());
        assertEquals(before, machine.configuration()[0]);
    }

    /** Una rueda desbloqueada SÍ debería poder volver a girar. */
    @Test
    public void unlockedWheelShouldSpinAgain() {
        machine.lock(1);
        machine.unlock(1);
        machine.spin(1);
        assertTrue(machine.ok());
    }

    // ---------------- placeSymbol ----------------

    /** placeSymbol SÍ debería colocar el color exacto pedido en la rueda. */
    @Test
    public void placeSymbolShouldSetGivenColor() {
        machine.placeSymbol(2, "blue");
        assertEquals("blue", machine.configuration()[1]);
        assertTrue(machine.ok());
    }

    /** placeSymbol NO debería aceptar un color que no está en el catálogo. */
    @Test
    public void placeSymbolShouldNotAcceptUnknownColor() {
        String before = machine.configuration()[1];
        machine.placeSymbol(2, "purple");
        assertFalse(machine.ok());
        assertEquals(before, machine.configuration()[1]);
    }

    // ---------------- spin(wheel, steps) ----------------

    /** spin con pasos negativos SÍ debería girar en sentido contrario. */
    @Test
    public void spinWithNegativeStepsShouldRotateBackwards() {
        machine.spin(1, 1);
        machine.spin(1, -1);
        assertEquals("red", machine.configuration()[0]);
        assertTrue(machine.ok());
    }

    /** spin(wheel,steps) NO debería tener éxito sin catálogo de símbolos. */
    @Test
    public void spinStepsShouldNotSucceedWithoutSymbols() {
        SlotMachine noSymbols = new SlotMachine();
        noSymbols.makeInvisible();
        noSymbols.addWheel(1);
        noSymbols.spin(1, 3);
        assertFalse(noSymbols.ok());
    }

    // ---------------- spin(setSymbols[]) ----------------

    /** spin(setSymbols) SÍ debería dejar la máquina en la configuración dada. */
    @Test
    public void spinWithArrayShouldSetExactConfiguration() {
        machine.spin(new String[]{"blue", "blue", "blue"});
        assertArrayEquals(new String[]{"blue", "blue", "blue"}, machine.configuration());
        assertTrue(machine.isJackpot());
    }

    /** spin(setSymbols) NO debería aplicar nada si un color no existe. */
    @Test
    public void spinWithArrayShouldNotApplyInvalidColor() {
        String[] before = machine.configuration();
        machine.spin(new String[]{"blue", "purple", "blue"});
        assertFalse(machine.ok());
        assertArrayEquals(before, machine.configuration());
    }
}