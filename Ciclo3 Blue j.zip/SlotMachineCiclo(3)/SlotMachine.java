
 import java.util.ArrayList;
 import java.util.Arrays;
 import java.util.Collections;
 import java.util.HashSet;
 import java.util.List;
 import java.util.Random;
 import java.util.Set;

/**
 * Simulador de una máquina tragamonedas.
 * Hereda (extends) de Maquina, que controla si está visible o no.
 *
 * IMPORTANTE: para RESOLVER el problema de la maratón, SlotMachineContest
 * solo puede usar SlotMachine(n), spin(wheel, steps) y distinctSymbols().
 * El resto de métodos son para simular/editar la máquina libremente.
 */
public class SlotMachine extends Maquina {

    private List<Wheel> wheels;
    private List<String> symbols;
    private boolean ok;

    public SlotMachine() {
        wheels = new ArrayList<>();
        symbols = new ArrayList<>();
        visible = false;
        ok = true;
    }

    /** Crea una máquina de n ruedas y n símbolos, inicializada al azar. */
    public SlotMachine(int n) {
        this();
        try {
            if (n <= 0) {
                throw new PosicionInvalidaException("n debe ser mayor que 0");
            }
            Random rnd = new Random();
            Set<String> colores = new HashSet<>();
            while (colores.size() < n) {
                colores.add(colorAleatorio(rnd));
            }
            symbols.addAll(colores);

            List<Integer> posiciones = new ArrayList<>();
            for (int i = 0; i < n; i++) posiciones.add(i);
            Collections.shuffle(posiciones, rnd);
            for (int i = 0; i < n; i++) {
                wheels.add(new Wheel(symbols, posiciones.get(i)));
            }
            ok = true;
        } catch (SlotMachineException e) {
            System.out.println("No se pudo crear la máquina: " + e.getMessage());
            ok = false;
        }
    }

    private String colorAleatorio(Random rnd) {
        return String.format("#%06X", rnd.nextInt(0xFFFFFF + 1));
    }

    // ---------------- Ruedas ----------------

    public void addWheel(int pos) {
        try {
            validarRueda(pos, wheels.size() + 1);
            int inicial = symbols.isEmpty() ? 0 : new Random().nextInt(symbols.size());
            wheels.add(pos - 1, new Wheel(symbols, inicial));
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void delWheel(int pos) {
        try {
            validarRueda(pos, wheels.size());
            wheels.remove(pos - 1);
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void swap(int wheel1, int wheel2) {
        try {
            validarRueda(wheel1, wheels.size());
            validarRueda(wheel2, wheels.size());
            Wheel w1 = wheels.get(wheel1 - 1);
            Wheel w2 = wheels.get(wheel2 - 1);
            wheels.set(wheel1 - 1, w2);
            wheels.set(wheel2 - 1, w1);
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void lock(int wheel) {
        try {
            validarRueda(wheel, wheels.size());
            wheels.get(wheel - 1).lock();
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void unlock(int wheel) {
        try {
            validarRueda(wheel, wheels.size());
            wheels.get(wheel - 1).unlock();
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    // ---------------- Símbolos ----------------

    public void addSymbol(int pos, String color) {
        try {
            if (pos < 1 || pos > symbols.size() + 1) {
                throw new PosicionInvalidaException("Posición de símbolo inválida: " + pos);
            }
            symbols.add(pos - 1, color);
            ok = true;
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void delSymbol(String symbol) {
        ok = symbols.remove(symbol);
    }

    public void placeSymbol(int wheel, String symbol) {
        try {
            validarRueda(wheel, wheels.size());
            if (!wheels.get(wheel - 1).placeSymbol(symbol)) {
                throw new SimboloInvalidoException("El símbolo no existe: " + symbol);
            }
            ok = true;
        } catch (SlotMachineException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    // ---------------- Giro ----------------

    public void spin(int wheel) {
        spin(wheel, 1);
    }

    /** Método clave que usa SlotMachineContest para resolver el problema. */
    public void spin(int wheel, int steps) {
        try {
            validarRueda(wheel, wheels.size());
            wheels.get(wheel - 1).spin(steps);
            ok = true;
            if (visible) mostrarEstado();
        } catch (PosicionInvalidaException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void spin(String[] setSymbols) {
        try {
            if (setSymbols == null || setSymbols.length != wheels.size()) {
                throw new SimboloInvalidoException("La cantidad de símbolos no coincide con las ruedas");
            }
            for (int i = 0; i < wheels.size(); i++) {
                if (!wheels.get(i).placeSymbol(setSymbols[i])) {
                    throw new SimboloInvalidoException("Símbolo inválido: " + setSymbols[i]);
                }
            }
            ok = true;
        } catch (SlotMachineException e) {
            System.out.println(e.getMessage());
            ok = false;
        }
    }

    public void spin() {
        for (int i = 1; i <= wheels.size(); i++) {
            spin(i, 1);
        }
    }

    // ---------------- Consulta ----------------

    public String[] symbols() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) result[i] = wheels.get(i).visibleSymbol();
        return result;
    }

    /** Oráculo usado por SlotMachineContest: cuántos símbolos distintos hay visibles. */
    public int distinctSymbols() {
        Set<String> distintos = new HashSet<>();
        for (Wheel w : wheels) distintos.add(w.visibleSymbol());
        return distintos.size();
    }

    public String[] configuration() {
        String[] result = new String[wheels.size()];
        for (int i = 0; i < wheels.size(); i++) result[i] = wheels.get(i).toString();
        return result;
    }

    public boolean isJackpot() {
        return !wheels.isEmpty() && distinctSymbols() == 1;
    }

    public void exit() {
        visible = false;
    }

    public boolean ok() {
        return ok;
    }

    private void validarRueda(int pos, int limite) throws PosicionInvalidaException {
        if (pos < 1 || pos > limite) {
            throw new PosicionInvalidaException("Rueda fuera de rango: " + pos);
        }
    }

    // ---------------- Polimorfismo: sobrescritura de métodos heredados ----------------

    @Override
    protected void mostrarEstado() {
        System.out.println(this);
    }

    @Override
    public String toString() {
        return Arrays.toString(symbols()) + (isJackpot() ? "  *** JACKPOT ***" : "");
    }
}   