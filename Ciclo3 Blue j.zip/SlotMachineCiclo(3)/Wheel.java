import java.util.List;
/**
 * 
 * Una rueda. Todas las ruedas de una misma SlotMachine comparten la
 * misma lista de símbolos (masterSymbols) pero cada una tiene su
 * propia posición (rotación).
 * 
 * @author (Juan R, Alejandra H) 
 * 
 */
public class Wheel {
 
    private List<String> masterSymbols;
    private int position;
    private boolean locked;
 
    public Wheel(List<String> masterSymbols, int initialPosition) {
        this.masterSymbols = masterSymbols;
        this.position = normalizar(initialPosition);
        this.locked = false;
    }
 
    private int normalizar(int p) {
        int n = masterSymbols.size();
        if (n == 0) return 0;
        int r = p % n;
        return r < 0 ? r + n : r;
    }
 
    public void spin(int steps) {
        if (!locked) {
            position = normalizar(position + steps);
        }
    }
 
    public String visibleSymbol() {
        return masterSymbols.isEmpty() ? null : masterSymbols.get(position);
    }
 
    public boolean placeSymbol(String symbol) {
        int idx = masterSymbols.indexOf(symbol);
        if (idx < 0) return false;
        position = idx;
        return true;
    }
 
    public void lock() { locked = true; }
    public void unlock() { locked = false; }
    public boolean isLocked() { return locked; }
 
    
    @Override
    public String toString() {
        return visibleSymbol() + (locked ? " [bloqueada]" : "");
    }
}