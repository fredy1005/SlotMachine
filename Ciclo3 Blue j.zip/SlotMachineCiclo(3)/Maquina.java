
/**
 * Write a description of class Maquina here.
 * 
 * @author (Juan Rodriguez, ASlejandra Hernandez) 
 * @version (a version number or a date)
 */
public abstract class Maquina {
 
    protected boolean visible;
 
    public void makeVisible() {
        visible = true;
        mostrarEstado();
    }
 
    public void makeInvisible() {
        visible = false;
    }
 
    public boolean estaVisible() {
        return visible;
    }
 
    // Método abstracto
    protected abstract void mostrarEstado();
}
 
