
/**
 * Excepción general de la máquina. Las excepciones más específicas
 * heredan de esta, así que un solo catch(SlotMachineException e)
 * puede atrapar cualquiera de ellas
 * 
 * @author (Juan R, Alejandra H) 
 * 
 */

public class SlotMachineException extends Exception {
    public SlotMachineException(String mensaje) {
        super(mensaje);
    }
}
 

class PosicionInvalidaException extends SlotMachineException {
    public PosicionInvalidaException(String mensaje) {
        super(mensaje);
    }
}
 

class SimboloInvalidoException extends SlotMachineException {
    public SimboloInvalidoException(String mensaje) {
        super(mensaje);
    }
}
 