import java.util.ArrayList;
import java.util.List;
/**
 * Estrategia en 4 fases
 * A) Dejar las n ruedas mostrando símbolos todos distintos.
 * B) Descubrir qué rueda está "un paso adelante" de cada una.
 * C) Con eso, calcular el desfase de cada rueda contra la rueda 1.
 * D) Corregir cada rueda de un solo giro para llegar al jackpot.
 * 
 * @author (Juan R , Alejandra H) 
 * 
 */

public class SlotMachineContest {
 
    private SlotMachine sm;
 
    public int[][] solve(int n) {
        List<int[]> acciones = new ArrayList<>();
        try {
            sm = new SlotMachine(n);
            if (n <= 1 || !sm.ok()) {
                return acciones.toArray(new int[0][]);
            }
 
            
            for (int rueda = 1; rueda <= n; rueda++) {
                int mejorPaso = 0;
                int mejorValor = sm.distinctSymbols();
                for (int paso = 1; paso <= n - 1; paso++) {
                    sm.spin(rueda, 1);
                    acciones.add(new int[]{rueda, 1});
                    int valor = sm.distinctSymbols();
                    if (valor > mejorValor) {
                        mejorValor = valor;
                        mejorPaso = paso;
                    }
                }
                int correccion = mejorPaso - (n - 1);
                if (correccion != 0) {
                    sm.spin(rueda, correccion);
                    acciones.add(new int[]{rueda, correccion});
                }
            }
 
            
            int[] siguiente = new int[n + 1];
            for (int i = 1; i <= n; i++) {
                int encontrada = -1;
                for (int j = 1; j <= n && encontrada == -1; j++) {
                    if (j == i) continue;
                    sm.spin(i, 1);  acciones.add(new int[]{i, 1});
                    sm.spin(j, -1); acciones.add(new int[]{j, -1});
                    if (sm.distinctSymbols() == n) {
                        encontrada = j;
                    }
                    sm.spin(i, -1); acciones.add(new int[]{i, -1});
                    sm.spin(j, 1);  acciones.add(new int[]{j, 1});
                }
                siguiente[i] = encontrada;
            }
 
            
            int[] desfase = new int[n + 1];
            int actual = 1;
            for (int paso = 1; paso < n; paso++) {
                actual = siguiente[actual];
                desfase[actual] = paso;
            }
 
            
            for (int i = 2; i <= n; i++) {
                if (desfase[i] != 0) {
                    sm.spin(i, -desfase[i]);
                    acciones.add(new int[]{i, -desfase[i]});
                }
            }
        } catch (RuntimeException e) {
            System.out.println("Ocurrió un error resolviendo la máquina: " + e.getMessage());
        }
        return acciones.toArray(new int[0][]);
    }
 
    
    public void simulate(int n) {
        solve(n);
        if (sm != null) {
            sm.makeVisible();
        }
    }
 
    public boolean isSolved() {
        return sm != null && sm.isJackpot();
    }
}